import requests
resp=requests.get("http://127.0.0.1:8000/fruit_predict/?dim=4.4&wt=50")
print(resp.json())