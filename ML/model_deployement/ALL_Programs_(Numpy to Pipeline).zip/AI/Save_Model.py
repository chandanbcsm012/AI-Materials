#!/usr/bin/env python
# coding: utf-8

# In[9]:


import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
df=pd.read_csv('c:/dataset/sentiment/spam_ham.txt',delimiter='\t')
df.columns=['label','msg']
X=df.msg
y=df.iloc[:,0].values
pipe=Pipeline([('tf',TfidfVectorizer(stop_words='english')),('mnb',MultinomialNB())])
pipe.fit(X,y)

import joblib
joblib.dump(pipe,'model.pkl')


# In[ ]:




