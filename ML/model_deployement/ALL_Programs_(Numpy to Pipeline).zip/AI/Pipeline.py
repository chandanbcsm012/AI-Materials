#!/usr/bin/env python
# coding: utf-8

# In[1]:


from sklearn.pipeline import Pipeline


# In[3]:


import pandas as pd


# In[4]:


df=pd.read_csv('c:/dataset/classification/fruits.csv')
X=df.iloc[:,:-1].values
y=df.iloc[:,-1].values


# In[8]:


from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,random_state=10)


# In[5]:


from sklearn.preprocessing import StandardScaler


# In[6]:


from sklearn.neighbors import KNeighborsClassifier


# In[22]:


pipe=Pipeline([('scalar',StandardScaler()),('knc',KNeighborsClassifier(n_neighbors=3))],verbose=True)


# In[23]:


pipe.fit(X_train,y_train)


# In[27]:


pipe.predict(X_test) #first do transforms then prediction


# In[25]:


pipe.score(X_train,y_train)


# In[26]:


pipe.score(X_test,y_test)

import joblib
joblib.dump(pipe,'model.pkl')
# In[ ]:




