#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


df=pd.read_csv('c:/dataset/classification/fruits.csv')
X=df.iloc[:,:-1].values
y=df.iloc[:,-1].values


# In[3]:


from sklearn.ensemble import AdaBoostClassifier


# In[9]:


abc=AdaBoostClassifier()#dtree,50,prob
abc.fit(X,y)
test_sample=[2.3,56]
print(abc.predict([test_sample]))
abc.estimator_weights_


# In[10]:


abc=AdaBoostClassifier(n_estimators=10)#dtree,10,prob
abc.fit(X,y)
test_sample=[2.3,56]
print(abc.predict([test_sample]))
abc.estimator_weights_


# In[15]:


abc=AdaBoostClassifier(algorithm='SAMME',n_estimators=10)#dtree,50,prob
abc.fit(X,y)
test_sample=[2.3,56]
print(abc.predict([test_sample]))
abc.estimator_weights_


# In[18]:


abc=AdaBoostClassifier(algorithm='SAMME.R',n_estimators=10)#dtree,50,prob
abc.fit(X,y)
test_sample=[2.3,56]
print(abc.predict([test_sample]))
print(abc.predict_proba([test_sample]))


# In[22]:


from sklearn.svm import SVC
abc=AdaBoostClassifier(base_estimator=SVC(probability=True),algorithm='SAMME',n_estimators=10)#dtree,50,prob
abc.fit(X,y)
test_sample=[2.3,56]
print(abc.predict([test_sample]))
print(abc.predict_proba([test_sample]))


# In[23]:


from sklearn.neighbors import KNeighborsClassifier
abc=AdaBoostClassifier(base_estimator=KNeighborsClassifier())#dtree,50,prob
abc.fit(X,y)
test_sample=[2.3,56]
print(abc.predict([test_sample]))


# In[27]:


df=pd.read_csv('c:/dataset/regression/salary_1_variable.csv')
X=df.iloc[:,:-1].values
y=df.iloc[:,-1].values


# In[28]:


from sklearn.ensemble import AdaBoostRegressor


# In[39]:


abr=AdaBoostRegressor()
abr.fit(X,y)
abr.predict([[15.1]])


# In[34]:


from sklearn.linear_model import LinearRegression


# In[40]:


abr=AdaBoostRegressor(base_estimator=LinearRegression())
abr.fit(X,y)
abr.predict([[15.1]])


# In[ ]:




