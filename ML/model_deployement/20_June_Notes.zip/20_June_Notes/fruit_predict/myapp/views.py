from django.shortcuts import render
import joblib
from django.http import JsonResponse

def fruit_predict(request):
	dim=float(request.GET.get('dim'))
	wt=float(request.GET.get('wt'))
	model=joblib.load('fruit_predict.pkl')
	pred=model.predict([[dim,wt]])
	return JsonResponse({'prediction':str(pred[0])})