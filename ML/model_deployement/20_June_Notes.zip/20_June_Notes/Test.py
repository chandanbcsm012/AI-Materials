import requests
resp=requests.get("http://ducatml.pythonanywhere.com/fruit_predict/?dim=2.1&wt=60")
print(resp.json())