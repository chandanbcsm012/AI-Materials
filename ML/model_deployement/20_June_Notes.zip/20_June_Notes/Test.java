import java.io.OutputStream;
import java.net.*;
import java.util.Scanner;
public class Test
{
	public static void main(String[] args) throws Exception
	{
		//URL url=new URL("http://127.0.0.1:8000/fruit_predict/?dim=2.4&wt=30");
URL url=new URL("http://ducatml.pythonanywhere.com/fruit_predict/?dim=2.1&wt=60");
		HttpURLConnection con=(HttpURLConnection)url.openConnection();
		con.setReadTimeout(10000);
		con.setConnectTimeout(15000);
		con.setRequestMethod("GET");
		con.setDoInput(true);
		con.setDoOutput(true);
		
		Scanner sc=new Scanner(con.getInputStream());
		System.out.println(sc.nextLine());
		sc.close();
	}
}
